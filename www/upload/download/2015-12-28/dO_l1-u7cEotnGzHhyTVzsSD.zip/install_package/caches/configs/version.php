<?php
return array(
'pc_version' => 'V9.5.10',	//phpcms 版本号
'pc_release' => '20150812',	//phpcms 更新日期
);
?>